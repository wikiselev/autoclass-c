#ifndef _MSC_VER
#define min(a,b) ( (a)<(b)?(a):(b) )
#define max(a,b) ( (a)>(b)?(a):(b) )
#endif
